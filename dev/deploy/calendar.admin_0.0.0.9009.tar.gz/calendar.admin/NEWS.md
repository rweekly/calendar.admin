# calendar.admin 0.0.0.9009

* Add NEWS file for changelog.
* Optimize Dockerfile with two stages of the build process.
